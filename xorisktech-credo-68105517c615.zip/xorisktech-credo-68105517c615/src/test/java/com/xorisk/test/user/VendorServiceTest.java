package com.xorisk.test.user;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.Vendor;
import com.xorisk.credo.data.repository.VendorRepository;

public class VendorServiceTest extends TestBase {

    @Autowired
    VendorRepository vendorRepository;

    @Test
    public void testListAllVendor() {
        List<Vendor> allVendors = vendorRepository.findAll();
        LOGGER.debug("All Vendor are {} ", StringUtils.join(allVendors));
    }

    @Test
    public void testAddVendor() {
        Vendor vendor = new Vendor();
        vendor.setName("Company1");
        vendor.setGstnId("1234");
        vendor.setState("Karnataka");
        vendor.setCity("Banglore");
        vendor.setPincode("560029");
        vendor.setAddress("6th main,BTM 2nd stage, Banglore India");

        vendorRepository.save(vendor);
    }

}
