package com.xorisk.test.util;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DateTests {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Test
    public void testDurationInYears() {
        Date dob = toDate(1990, Calendar.APRIL, 14);
        ZoneId zoneId = ZoneId.systemDefault();
        Period period = Period.between(dob.toInstant().atZone(zoneId).toLocalDate(), LocalDate.now());
        LOGGER.debug("Period since {} is {} ", dob, period);
        assert (period.getYears() == 28);
    }

    private Date toDate(int year, int month, int date) {
        Calendar calendar = GregorianCalendar.getInstance();
        calendar.set(year, month, date);
        return calendar.getTime();
    }
}
