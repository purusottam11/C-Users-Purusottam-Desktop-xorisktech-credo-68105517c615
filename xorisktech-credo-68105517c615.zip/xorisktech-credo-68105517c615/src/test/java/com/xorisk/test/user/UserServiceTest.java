package com.xorisk.test.user;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.User;
import com.xorisk.credo.data.repository.UserRepository;
import com.xorisk.credo.service.api.UserService;

public class UserServiceTest extends TestBase {
    @Autowired
    private UserService userService;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void listAllUsers() {
        List<User> allUser = userService.getAllUsers();
        LOGGER.debug("group all users : {} ", StringUtils.join(allUser), "\n");
    }
    //
    // @Test
    // public void testSearchByEmailId() {
    // assert (userRepository.findByEmailId("thisis@notpresent.com") == null);
    // assert (userRepository.findByEmailId("tfairey0@webmd.com") != null);
    // }
    //
    // @Test
    // public void testGroupUsersByState() {
    // List<User> allUsers = userService.getAllUsers();
    // Map<String, List<User>> groupdByState = userService.groupUsersByState();
    // assert (groupdByState.containsKey("Texas"));
    // List<User> texasUsers = groupdByState.get("Texas");
    // assert (texasUsers.size() == 3);
    // assert (texasUsers.get(0).getFirstName().equals("Delmor"));
    // assert (texasUsers.get(1).getFirstName().equals("Griffy"));
    // assert (texasUsers.get(2).getFirstName().equals("Merci"));
    // LOGGER.debug("allUsers: {}", StringUtils.join(allUsers, "\n"));
    //
    // }
    //
    // @Test
    // public void listUserSortedByage() {
    // List<User> sortedUser = userService.listUsersSortedByAge();
    // LOGGER.debug("The sorted Users : {}", StringUtils.join(sortedUser), "\n");
    // }
    //
    // @Test
    // public void testListUsersSortedByName() {
    // List<User> sortedUsers = userService.listUsersSortedByName();
    // LOGGER.debug("Sorted user : {} ", StringUtils.join(sortedUsers, "\n"));
    // }
    //
    // @Test
    // public void testListUsersSortedByAge() {
    // List<User> sortedUsers = userService.listUsersSortedByAge();
    // LOGGER.debug("Sorted user : {} ", StringUtils.join(sortedUsers, "\n"));
    // }
    //
    // @Test
    // public void testFindUsersInAgeRange() throws Exception {
    // int age_10_20 = userService.findUsersInAgeRange(10, 20).size();
    // LOGGER.debug("age_10_20 size - {}", age_10_20);
    // assert (age_10_20 == 2);
    // User userAt_1 = userService.findUsersInAgeRange(10, 20).get(1);
    // assert (userAt_1.getFirstName().equals("Vita"));
    // assert (userService.findUsersInAgeRange(20, null).size() == 18);
    // assert (userService.findUsersInAgeRange(null, 40).size() == 11);
    // }
    //
    // @Test
    // public void testFindUserByGender() {
    // List<User> findUsersByGender = userService.findUsersByGender(Gender.MALE);
    // assert (findUsersByGender != null);
    // assert (findUsersByGender.size() == 13);
    // assert (userService.findUsersByGender(Gender.FEMALE).size() == 7);
    // }
    //
    // @Test
    // public void testSearchFilter() {
    // UserSearchFilter searchFilterFemale = new UserSearchFilter();
    // searchFilterFemale.setGender(Gender.FEMALE);
    // assert (userService.search(searchFilterFemale).size() == 7);
    // UserSearchFilter searchFilterEmailMale = new UserSearchFilter();
    // searchFilterEmailMale.setEmailId("bstranieri4@ocn.ne.jp");
    // searchFilterEmailMale.setGender(Gender.MALE);
    // assert (userService.search(searchFilterEmailMale).size() == 1);
    // }
    //
    // @Test
    // public void testfindUsersWithName() {
    // assert (userService.findUsersWithName("Delmor").size() == 1);
    // assert (userService.findUsersWithName("lmor").size() == 1);
    // assert
    // (userService.findUsersWithName("lmor").get(0).getFirstName().equals("Delmor"));
    // assert (userService.findUsersWithName("Walden").size() == 1);
    // assert (userService.findUsersWithName("aaaaaa").size() == 0);
    // }
    //
    // @Test
    // public void testgroupUsersByMonthOfBirth() {
    // List<User> allUsers = userService.getAllUsers();
    // Map<Month, List<User>> groupdBydob = userService.groupUsersByMonthOfBirth();
    // assert (groupdBydob.containsKey("JANUARY"));
    // List<User> list = groupdBydob.get("JANUARY");
    // assert (list.size() == 3);
    // assert (list.get(0).getFirstName().equals("Delmor"));
    // assert (list.get(1).getFirstName().equals("Vita"));
    // assert (list.get(2).getFirstName().equals("Conroy"));
    // LOGGER.debug("allUsers: {}", StringUtils.join(allUsers, "\n"));
    //
    // }
    //
    // @Test
    // public void testdelete() throws Exception {
    // List<User> allUsers = userService.getAllUsers();
    // assert (userService.delete("rkleisg@hexun.com"));
    // LOGGER.debug("allUsers: {}", StringUtils.join(allUsers, "\n"));
    //
    // }

    // @Test
    // public void testAddUser() {
    // User user = new User();
    // user.setFirstName("Purusottam");
    // user.setLastName("Mohapatra");
    // user.setCity("Banglore");
    // user.setEmailId("abc@gmail.com");
    // userService.addUser(user);
    // assert (userRepository.count() == 25);
    // }
}
