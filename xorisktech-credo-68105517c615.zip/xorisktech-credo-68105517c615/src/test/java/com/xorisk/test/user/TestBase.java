package com.xorisk.test.user;

import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.xorisk.credo.CredoApplication;

@ExtendWith(SpringExtension.class)
@SpringBootTest(classes = { CredoApplication.class })
@TestInstance(Lifecycle.PER_CLASS)
public class TestBase {

    protected static final Logger LOGGER = LoggerFactory.getLogger(TestBase.class);

}
