package com.xorisk.test.user;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.RecordPayment;
import com.xorisk.credo.data.RecordPayment.ModeOfPayment;
import com.xorisk.credo.data.repository.RecordPaymentRepository;

public class RecordPaymentServiceTest extends TestBase {

    @Autowired
    RecordPaymentRepository recordPaymentRepository;

    @Test
    public void testListAllPaymentRecord() {
        List<RecordPayment> recordpayment = recordPaymentRepository.findAll();
        LOGGER.debug("All payment records are {} ", StringUtils.join(recordpayment));
    }

    @Test
    public void testAddRecordPayment() {
        Date date = new Date();

        RecordPayment recordPayment = new RecordPayment();
        recordPayment.setInvoiceNumber((long) 12345);// this is the mapping to invoice table
        recordPayment.setInvoiceAmount(100000);
        recordPayment.setModeOfPayment(ModeOfPayment.BANK_TRANSFER);
        recordPayment.setPaidAmount(120000);
        recordPayment.setTds(1000);
        recordPayment.setPaymentDate(date);
        recordPayment.setReferenceNumber("123654");
        recordPayment.setComments("Any comments");

        recordPaymentRepository.save(recordPayment);
    }

}
