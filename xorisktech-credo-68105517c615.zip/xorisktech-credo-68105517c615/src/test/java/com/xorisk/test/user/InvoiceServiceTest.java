package com.xorisk.test.user;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.Invoice;
import com.xorisk.credo.data.Invoice.InvoiceStatus;
import com.xorisk.credo.data.repository.InvoiceRepository;

public class InvoiceServiceTest extends TestBase {

    private static final InvoiceStatus PAID = null;
    @Autowired
    InvoiceRepository invoiceRepository;

    @Test
    public void testListAllInvoice() {
        List<Invoice> allInvoice = invoiceRepository.findAll();
        LOGGER.debug("All invoice are {} ", allInvoice);
    }

    @Test
    public void testAddInvice() {
        Date date = new Date();

        Invoice invoice = new Invoice();
        invoice.setInvoicedate(date);
        invoice.setInvoiceNumber("123456");
        invoice.setVendorId((long) 100);// this is the mapping to vendor
        invoice.setInvoiceAmount(100000);
        invoice.setIgst(true);
        invoice.setSgstOrGst(false);
        invoice.setIgstAmount(200);
        invoice.setGstAmount(0.0f);
        invoice.setSgstAmount(0.0f);
        invoice.setTaxNumber("12345");
        invoice.setTotalAmount(120000);
        invoice.setInvoiceStatus(PAID);

        invoiceRepository.save(invoice);

    }
}
