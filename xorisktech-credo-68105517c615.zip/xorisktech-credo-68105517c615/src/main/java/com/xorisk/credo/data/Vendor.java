package com.xorisk.credo.data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "VENDOR")
public class Vendor extends AuditableIdEntity {

    @Column(name = "NAME")
    private String name;

    @Column(name = "GSTN_ID")
    private String gstnId;

    @Column(name = "STATE")
    private String state;

    @Column(name = "CITY")
    private String city;

    @Column(name = "PINCODE")
    private String pincode;

    @Column(name = "ADDRESS")
    private String address;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getGstnId() {
        return gstnId;
    }

    public void setGstnId(String gstnId) {
        this.gstnId = gstnId;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Vendor [name=" + name + ", gstnId=" + gstnId + ", state=" + state + ", city=" + city + ", pincode=" + pincode + ", address=" + address + "]";
    }

}
