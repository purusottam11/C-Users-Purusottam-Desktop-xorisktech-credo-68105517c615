package com.xorisk.credo.service.api;

import java.util.List;

import com.xorisk.credo.data.Vendor;

public interface VendorService {

    Vendor addVendor(Vendor vendor);

    Vendor upDateVendor(String gstnId, Vendor vendor);

    boolean deleteVendor(String gstnId, Vendor vendor);

    List<Vendor> getAllVendor();

}
