package com.xorisk.credo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.xorisk.credo.data.User;
import com.xorisk.credo.data.User.Gender;
import com.xorisk.credo.data.repository.UserRepository;

@Component
public class CredoInit implements ApplicationListener<ContextRefreshedEvent> {

    private final Logger LOGGER = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private UserRepository userRepository;

    @Override
    public void onApplicationEvent(ContextRefreshedEvent event) {
        try {
            loadDummyData();
        } catch (Exception e) {
            throw new ApplicationContextException("Unable to init DB", e);
        }
    }

    private void loadDummyData() throws Exception {
        if (userRepository.count() == 0) {
            LOGGER.debug("Loading dummy data...");
            userRepository.saveAll(getDummyData());
        }
    }

    private List<User> getDummyData() throws FileNotFoundException, IOException, ParseException {
        List<User> users = new ArrayList<>();
        // Get file from resources folder
        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource("sampleusers.txt").getFile());
        List<String> lines = IOUtils.readLines(new FileReader(file));
        LOGGER.debug("Found {} lines in dummy data file", lines.size());
        for (String line : lines) {
            if (StringUtils.startsWith(line, "//")) {
                LOGGER.debug("Ignoring comment line :{}", line);
                continue;
            }
            String[] info = StringUtils.split(line, ",");
            // first_name,last_name,email,gender,dob,address,city,state,pincode,phone,website,note
            users.add(new User(info[0], info[1], info[2], Gender.parse(info[3]), DateUtils.parseDate(info[4], "MM/dd/yyyyy"), info[5], info[6], info[7], info[8], info[9], info[10], info[11], info[12]));
        }
        LOGGER.debug("Found {} user info in dummy data file", users.size());
        return users;
    }
}
