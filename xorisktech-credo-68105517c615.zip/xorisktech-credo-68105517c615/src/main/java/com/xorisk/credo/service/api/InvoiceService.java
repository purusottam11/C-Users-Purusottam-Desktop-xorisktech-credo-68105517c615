package com.xorisk.credo.service.api;

import java.util.List;

import com.xorisk.credo.data.Invoice;

public interface InvoiceService {

    Invoice addInvoice(Invoice invoice);

    Invoice upDateInvoice(String invoiceNumber, Invoice invoice);

    boolean deleteInvoice(String invoiceNumber, Invoice invoice);

    List<Invoice> getAllInvoice();

    List<Invoice> listInvoiceSortByInvoiceDate();

    List<Invoice> listInvoiceSortByInvoiceStatus();

}
