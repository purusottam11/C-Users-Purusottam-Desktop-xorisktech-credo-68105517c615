package com.xorisk.credo.service.api;

import java.util.List;

import org.springframework.stereotype.Component;

import com.xorisk.credo.data.Expense;
import com.xorisk.credo.web.bean.ExpenseSearchFilter;

@Component
public interface ExpenseService {
    // Methods for Expenses
    List<Expense> getAllExpenses();

    Expense getExpense(Long id);

    Expense addExpense(Expense expense);

    Expense updateExpense(Expense expense);

    List<Expense> search(ExpenseSearchFilter expenseSearchFilter);

}
