package com.xorisk.credo.data;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Table;

//@Entity
@Table(name = "TITLE")
@DiscriminatorValue("2")
public class Title {

    String titleName;
}
