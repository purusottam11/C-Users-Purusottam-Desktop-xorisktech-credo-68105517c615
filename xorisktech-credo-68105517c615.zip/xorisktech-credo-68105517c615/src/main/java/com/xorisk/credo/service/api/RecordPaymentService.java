package com.xorisk.credo.service.api;

import java.util.List;

import com.xorisk.credo.data.Invoice;
import com.xorisk.credo.data.RecordPayment;

public interface RecordPaymentService {

    List<RecordPayment> listAllRecordPayment();

    RecordPayment addRecordPayment(RecordPayment recordPayment);

    RecordPayment upDateRecordPayment(RecordPayment recordPayment);

    float totalAmounToPay(Invoice invoice);

    float totalPaymenPaytWithTDS(Invoice invoice);

}
