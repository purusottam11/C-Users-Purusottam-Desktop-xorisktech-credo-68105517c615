package com.xorisk.credo;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;
import org.springframework.lang.NonNull;

@Entity
@Table(name = "EMPLOYEE")
public class Employee {

    public enum Department {
        Engineering, Marketing, Sales, Hr;
        public static Department parse(String employeeDepartment) {
            for (Department department : values()) {
                if (StringUtils.endsWithIgnoreCase(department.name(), employeeDepartment)) {
                    return department;
                }
            }
            return null;
        }
    }

    public enum Title {
        Developer, Tester, technical;
        public static Title parse(String employeeTitle) {
            for (Title title : values()) {
                if (StringUtils.endsWithIgnoreCase(title.name(), employeeTitle)) {
                    return title;
                }
            }
            return null;
        }
    }

    @NonNull
    @Id
    @Column(name = "ID")
    Long id;

    @NonNull
    @Column(name = "EMPLOYEE_ID")
    String employeeId;

    @NonNull
    @Column(name = "DEPARTMENT")
    Department department;

    @NonNull
    @Column(name = "TITLE")
    Title title;

}
