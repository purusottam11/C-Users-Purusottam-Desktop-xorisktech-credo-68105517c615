package com.xorisk.credo.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.xorisk.credo.data.Vendor;

public interface VendorRepository extends JpaRepository<Vendor, Long>, JpaSpecificationExecutor<Vendor> {

    @Query("select v from Vendor v where v.gstnId=:gstnId")
    Vendor findByGstnId(@Param("gstnId") String gstnId);

}
