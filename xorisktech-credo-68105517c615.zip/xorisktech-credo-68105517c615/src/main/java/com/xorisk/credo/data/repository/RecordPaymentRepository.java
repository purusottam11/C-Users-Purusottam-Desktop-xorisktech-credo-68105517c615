package com.xorisk.credo.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.xorisk.credo.data.RecordPayment;

public interface RecordPaymentRepository extends JpaRepository<RecordPayment, Long>, JpaSpecificationExecutor<RecordPayment> {

}
