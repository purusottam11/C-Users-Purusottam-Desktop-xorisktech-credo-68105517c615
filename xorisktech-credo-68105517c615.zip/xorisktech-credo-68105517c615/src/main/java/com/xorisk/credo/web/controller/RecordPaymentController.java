package com.xorisk.credo.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;

@Controller
public class RecordPaymentController {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

}
