package com.xorisk.credo.service.core;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.Vendor;
import com.xorisk.credo.data.repository.VendorRepository;
import com.xorisk.credo.service.api.VendorService;
import com.xorisk.credo.web.BusinessException;

public class VendorServiceImpl implements VendorService {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    VendorRepository vendorRepository;

    public VendorServiceImpl(VendorRepository vendorRepository) {
        this.vendorRepository = vendorRepository;
    }

    @Override
    public Vendor addVendor(Vendor vendor) {
        // TODO Auto-generated method stub
        if (vendorRepository.findByGstnId(vendor.getGstnId()) != null) {
            LOGGER.debug("Vendor is already present in the DB ", StringUtils.join(vendor));
            throw new BusinessException("Vendor is already present in the DB");
        }
        LOGGER.debug("Vendor Added succifully {}", StringUtils.join(vendor));
        return vendorRepository.save(vendor);
    }

    @Override
    public Vendor upDateVendor(String gstnId, Vendor vendor) {
        // TODO Auto-generated method stub
        if (vendorRepository.findByGstnId(gstnId) == null) {
            LOGGER.debug("Vendor is not there in DB {}", StringUtils.join(vendor));
            throw new BusinessException("Vendor is not there in DB ");
        }
        LOGGER.debug("Vendor updated succifully {}", StringUtils.join(vendor));
        return vendorRepository.save(vendor);
    }

    @Override
    public boolean deleteVendor(String gstnId, Vendor vendor) {
        // TODO Auto-generated method stub
        if (vendorRepository.findByGstnId(gstnId) == null) {
            LOGGER.debug("Vendor is not there in DB {}", StringUtils.join(vendor));
            throw new BusinessException("Vendor is not there in DB ");
        }
        vendorRepository.delete(vendor);
        LOGGER.debug("Vendor deleted succifully {}", StringUtils.join(vendor));
        return true;

    }

    @Override
    public List<Vendor> getAllVendor() {
        // TODO Auto-generated method stub
        LOGGER.debug("All vendor are ...: ");
        return vendorRepository.findAll();
    }

}
