package com.xorisk.credo.web.bean;

import com.xorisk.credo.data.User.Gender;

public class UserSearchFilter {
    private String emailId;
    private Gender gender;
    private Integer minAge;
    private Integer maxAge;

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Integer getMinAge() {
        return minAge;
    }

    public void setMinAge(Integer minAge) {
        this.minAge = minAge;
    }

    public Integer getMaxAge() {
        return maxAge;
    }

    public void setMaxAge(Integer maxAge) {
        this.maxAge = maxAge;
    }

    @Override
    public String toString() {
        return "UserSearchFilter [emailId=" + emailId + ", gender=" + gender + ", minAge=" + minAge + ", maxAge=" + maxAge + "]";
    }

}
