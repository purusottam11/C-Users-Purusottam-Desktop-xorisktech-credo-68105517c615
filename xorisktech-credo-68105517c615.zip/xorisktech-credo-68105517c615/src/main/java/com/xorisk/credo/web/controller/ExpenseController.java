package com.xorisk.credo.web.controller;

import java.util.List;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.xorisk.credo.data.Expense;
import com.xorisk.credo.service.api.ExpenseService;

@Controller
public class ExpenseController {
    private final Logger LOGGER = LoggerFactory.getLogger(getClass());
    @Autowired
    private ExpenseService expenseService;

    @GetMapping("/expenses")
    public String getAllExpenses(Model model) {
        List<Expense> allExpenses = expenseService.getAllExpenses();
        model.addAttribute("expenses", allExpenses);
        return "expenses";
    }

    @GetMapping("/expense/")
    public String gotoAddExpensePage(Model model, RedirectAttributes redirectAttributes) {
        return gotoExpenseDetailsPage(null, model, redirectAttributes);
    }

    @PostMapping("/expense/")
    public String addExpense(@ModelAttribute @Valid Expense expense, Model model, RedirectAttributes redirectAttributes) {
        // TODO add validations
        String message;
        try {
            expense = expenseService.addExpense(expense);
            message = "Expanse added successfully";
        } catch (Exception e) {
            LOGGER.error("Error while adding Expenses", e);
            message = "Unable to add expense";
        }
        model.addAttribute("expense", expense);
        redirectAttributes.addFlashAttribute("status", message);
        return "redirect:/expenses";
    }

    @GetMapping("/expense/{expenseId}")
    public String gotoExpenseDetailsPage(@PathVariable(value = "expenseId", required = false) Long expenseId, Model model, RedirectAttributes redirectAttributes) {
        if (expenseId == null) {
            model.addAttribute("expense", new Expense());
        } else {
            model.addAttribute("expense", expenseService.getExpense(expenseId));
        }
        model.addAttribute("types", Expense.Type.values());

        return "expense";

    }

    @PostMapping("/expense/{expenseId}")
    public String updateExpense(@PathVariable(value = "expenseId", required = false) Long expenseId, @ModelAttribute @Valid Expense expense, BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes) {
        // TODO add validations
        String message;
        String nextPage;
        try {
            expense = expenseService.updateExpense(expense);
            message = "User added successfully";
            nextPage = getAllExpenses(model);
        } catch (Exception e) {
            LOGGER.error("Error while adding expense", e);
            message = "Unable to add expense";
            nextPage = gotoExpenseDetailsPage(expenseId, model, redirectAttributes);
        }
        redirectAttributes.addFlashAttribute("status", message);
        return "redirect:/" + nextPage;
    }

}
