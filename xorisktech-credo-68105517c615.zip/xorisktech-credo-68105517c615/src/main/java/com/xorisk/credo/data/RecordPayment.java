package com.xorisk.credo.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;

@Entity
@Table(name = "PAYMENT")
public class RecordPayment extends AuditableIdEntity {

    public enum ModeOfPayment {
        CASH, CHEQUE, BANK_TRANSFER;

        public static ModeOfPayment parse(String modeOfPaymentString) {
            for (ModeOfPayment modeOfpayment : values()) {
                if (StringUtils.endsWithIgnoreCase(modeOfpayment.name(), modeOfPaymentString)) {
                    return modeOfpayment;
                }
            }
            return null;
        }
    }

    // this is map to invoice table
    @Column(name = "INVOICE_NUMBER")
    private Long invoiceNumber;

    @Column(name = "INVOICE_AMOUNT")
    private float invoiceAmount;

    @Column(name = "MODE_OF_PAYMENT")
    private ModeOfPayment modeOfPayment;

    @Column(name = "PAID_AMOUNT")
    private float paidAmount;

    @Column(name = "TDS")
    private float tds;

    @Column(name = "PAYMENT_DATE")
    private Date paymentDate;

    @Column(name = "REFERENCE_NUMBER")
    private String referenceNumber;

    @Column(name = "COMMENTS")
    private String comments;

    public Long getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(Long invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public float getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(float invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public ModeOfPayment getModeOfPayment() {
        return modeOfPayment;
    }

    public void setModeOfPayment(ModeOfPayment modeOfPayment) {
        this.modeOfPayment = modeOfPayment;
    }

    public float getPaidAmount() {
        return paidAmount;
    }

    public void setPaidAmount(float paidAmount) {
        this.paidAmount = paidAmount;
    }

    public float getTds() {
        return tds;
    }

    public void setTds(float tds) {
        this.tds = tds;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public String getReferenceNumber() {
        return referenceNumber;
    }

    public void setReferenceNumber(String referenceNumber) {
        this.referenceNumber = referenceNumber;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    @Override
    public String toString() {
        return "RecordPayment [invoiceNumber=" + invoiceNumber + ", invoiceAmount=" + invoiceAmount + ", modeOfPayment=" + modeOfPayment + ", paidAmount=" + paidAmount + ", tds=" + tds + ", paymentDate=" + paymentDate + ", referenceNumber="
                + referenceNumber + ", comments=" + comments + "]";
    }

}
