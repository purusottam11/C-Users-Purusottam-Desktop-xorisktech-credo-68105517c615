package com.xorisk.credo.data.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.xorisk.credo.data.User;
import com.xorisk.credo.data.User.Gender;

public interface UserRepository extends JpaRepository<User, Long>, JpaSpecificationExecutor<User> {

    @Query("select u from User u where u.emailId=:emailId")
    User findByEmailId(@Param("emailId") String emailId);

    @Query("select u from User u where u.gender=:gender")
    List<User> findUsersByGender(@Param("gender") Gender gender);

    @Query("select u from User u where u.firstName like %:searchString% or u.lastName like %:searchString%")
    List<User> findUsersWithNameContaining(@Param("searchString") String searchString);

}