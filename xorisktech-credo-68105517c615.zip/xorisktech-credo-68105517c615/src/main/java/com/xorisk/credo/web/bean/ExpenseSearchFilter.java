package com.xorisk.credo.web.bean;

import java.util.Date;

import com.xorisk.credo.data.Expense.Type;

public class ExpenseSearchFilter {

    private Date minDoe;

    private Date maxDoe;

    private String projectName;
    // private String venderNAme;
    private Type type;

    public Date getMinDoe() {
        return minDoe;
    }

    public void setMinDoe(Date minDoe) {
        this.minDoe = minDoe;
    }

    public Date getMaxDoe() {
        return maxDoe;
    }

    public void setMaxDoe(Date maxDoe) {
        this.maxDoe = maxDoe;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    // public String getVenderNAme() {
    // return venderNAme;
    // }
    //
    // public void setVenderNAme(String venderNAme) {
    // this.venderNAme = venderNAme;
    // }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "ExpenseSearchFilter [minDoe=" + minDoe + ", maxDoe=" + maxDoe + ", projectName=" + projectName + ", type=" + type + "]";
    }

}
