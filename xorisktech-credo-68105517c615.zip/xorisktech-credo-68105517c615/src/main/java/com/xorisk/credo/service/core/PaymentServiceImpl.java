package com.xorisk.credo.service.core;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.xorisk.credo.data.Invoice;
import com.xorisk.credo.data.RecordPayment;
import com.xorisk.credo.data.repository.RecordPaymentRepository;
import com.xorisk.credo.service.api.RecordPaymentService;

public class PaymentServiceImpl implements RecordPaymentService {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    RecordPaymentRepository paymentRepository;

    public PaymentServiceImpl(RecordPaymentRepository paymentRepository) {
        this.paymentRepository = paymentRepository;
    }

    @Override
    public List<RecordPayment> listAllRecordPayment() {
        // TODO Auto-generated method stub
        LOGGER.debug("All Payment records are ..");
        return paymentRepository.findAll();
    }

    @Override
    public RecordPayment addRecordPayment(RecordPayment recordPayment) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public RecordPayment upDateRecordPayment(RecordPayment recordPayment) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public float totalAmounToPay(Invoice invoice) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public float totalPaymenPaytWithTDS(Invoice invoice) {
        // TODO Auto-generated method stub
        return 0;
    }

}
