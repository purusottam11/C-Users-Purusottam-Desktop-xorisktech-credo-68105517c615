package com.xorisk.credo.service.core;

import java.time.LocalDate;
import java.time.Month;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.xorisk.credo.data.User;
import com.xorisk.credo.data.User.Gender;
import com.xorisk.credo.data.repository.UserRepository;
import com.xorisk.credo.service.api.UserService;
import com.xorisk.credo.web.BusinessException;
import com.xorisk.credo.web.bean.UserSearchFilter;

@Component
public class UserServiceImpl implements UserService {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    private UserRepository userRepository;

    public UserServiceImpl(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    @Override
    public User getUser(Long userId) {
        return userRepository.getOne(userId);

    }

    @Override
    public List<User> getAllUsers() {
        LOGGER.trace("Returning all users");
        return userRepository.findAll();
    }

    @Override
    public User addUser(User user) throws NullPointerException {
        if (userRepository.findByEmailId(user.getEmailId()) != null) {
            LOGGER.debug("User already exist ", user);
            throw new BusinessException("The User is already exist :");
        }

        userRepository.save(user);
        LOGGER.debug("New User added {}", user);
        return user;
    }

    @Override
    public List<User> listUsersSortedByName() {
        return userRepository.findAll(Sort.by("firstName").and(Sort.by("lastName")));
    }

    @Override
    public List<User> listUsersSortedByAge() {
        return userRepository.findAll(Sort.by("dob"));
    }

    @Override
    public List<User> findUsersWithName(String searchString) {
        return userRepository.findUsersWithNameContaining(searchString);
    }

    @Override
    public List<User> findUsersByGender(Gender gender) {
        return userRepository.findUsersByGender(gender);
    }

    @Override
    public User findByEmailId(String emailId) {
        return userRepository.findByEmailId(emailId);
    }

    @Override
    public List<User> findUsersInAgeRange(Integer minAge, Integer maxAge) {
        if (maxAge == null && minAge == null) {
            throw new BusinessException("Both minAge & maxAge cireria cannot be null");
        }
        return userRepository.findAll(getAgeRangeSpec(minAge, maxAge));
    }

    private Specification<User> getAgeRangeSpec(Integer minAge, Integer maxAge) {
        Specification<User> ageRangeSpec = new Specification<User>() {
            @Override
            public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                LocalDate minYear = minAge == null ? null : LocalDate.now().minusYears(minAge);
                LocalDate maxYear = maxAge == null ? null : LocalDate.now().minusYears(maxAge);
                Date minDate = minYear == null ? null : Date.from(minYear.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());
                Date maxDate = maxYear == null ? null : Date.from(maxYear.atStartOfDay().atZone(ZoneId.systemDefault()).toInstant());

                if (minDate != null && maxDate != null) {
                    return criteriaBuilder.between(root.get("dob"), maxDate, minDate);
                } else if (minDate == null) {
                    return criteriaBuilder.greaterThanOrEqualTo(root.get("dob"), maxDate);
                } else if (maxDate == null) {
                    return criteriaBuilder.lessThanOrEqualTo(root.get("dob"), minDate);
                }
                return null;
            }
        };
        return ageRangeSpec;
    }

    @Override
    public Map<String, List<User>> groupUsersByState() {
        // TODO in JPA query
        Map<String, List<User>> groupedUsers = new TreeMap<>();
        List<User> allUsers = (List<User>) userRepository.findAll();
        for (User user : allUsers) {
            String state = user.getState();
            List<User> userGroup = groupedUsers.get(state);
            if (userGroup == null) {
                userGroup = new ArrayList<User>();
                groupedUsers.put(state, userGroup);
            }
            userGroup.add(user);
        }
        return groupedUsers;
    }

    @Override
    public Map<Month, List<User>> groupUsersByMonthOfBirth() {
        // TODO in JPA query
        Map<Month, List<User>> groupedUsers = new TreeMap<>();

        for (User user : userRepository.findAll()) {
            Month month = user.getDob().toInstant().atZone(ZoneId.systemDefault()).getMonth();
            List<User> userGroup = groupedUsers.get(month);
            if (userGroup == null) {
                userGroup = new ArrayList<User>();
                groupedUsers.put(month, userGroup);
            }
            userGroup.add(user);
        }
        return groupedUsers;
    }

    @Override
    public List<User> search(UserSearchFilter userSearchFilter) {

        Specification<User> searchSpec = new Specification<User>() {
            @Override
            public Predicate toPredicate(Root<User> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {

                List<Predicate> predicates = new ArrayList<>();

                if (StringUtils.isNotBlank(userSearchFilter.getEmailId())) {
                    predicates.add(criteriaBuilder.equal(root.get("emailId"), userSearchFilter.getEmailId()));
                } else if (userSearchFilter.getGender() != null) {
                    predicates.add(criteriaBuilder.equal(root.get("gender"), userSearchFilter.getGender()));
                } else if (userSearchFilter.getMinAge() != null || userSearchFilter.getMaxAge() != null) {
                    predicates.add(getAgeRangeSpec(userSearchFilter.getMinAge(), userSearchFilter.getMaxAge()).toPredicate(root, query, criteriaBuilder));
                }
                return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
            }
        };

        List<User> searchResult = userRepository.findAll(searchSpec);

        LOGGER.debug("Search {} ", userSearchFilter);
        LOGGER.debug("Result {} ", searchResult);
        return searchResult;
    }

    @Override
    public User updateUser(Long userId, User user) {
        Optional<User> userInDb = userRepository.findById(userId);
        if (!userInDb.isPresent()) {
            throw new BusinessException("User not found");
        }

        LOGGER.debug("User {} updated", user.getEmailId());
        userRepository.save(user);
        return user;
    }

    @Override
    public boolean delete(String emailId) throws Exception {
        User user = userRepository.findByEmailId(emailId);
        if (user == null) {
            throw new BusinessException("User not found");
        }
        user.setDeleted(true);
        userRepository.save(user);
        return true;
    }
}
