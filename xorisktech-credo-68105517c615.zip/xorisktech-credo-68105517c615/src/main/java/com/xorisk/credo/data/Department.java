package com.xorisk.credo.data;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Table;

//@Entity
@Table(name = "DEPARTMENT")
@DiscriminatorColumn(name = "DISC", discriminatorType = DiscriminatorType.STRING, length = 20)
@DiscriminatorValue("1")

public class Department {

    String departmentname;
}
