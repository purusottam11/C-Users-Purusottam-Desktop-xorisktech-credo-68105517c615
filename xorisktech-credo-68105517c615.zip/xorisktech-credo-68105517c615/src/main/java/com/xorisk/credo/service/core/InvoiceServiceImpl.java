package com.xorisk.credo.service.core;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;

import com.xorisk.credo.data.Invoice;
import com.xorisk.credo.data.repository.InvoiceRepository;
import com.xorisk.credo.service.api.InvoiceService;
import com.xorisk.credo.web.BusinessException;

public class InvoiceServiceImpl implements InvoiceService {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    InvoiceRepository invoiceRepository;

    public InvoiceServiceImpl(InvoiceRepository invoiceRepository) {
        this.invoiceRepository = invoiceRepository;
    }

    @Override
    public Invoice addInvoice(Invoice invoice) {
        // TODO Auto-generated method stub
        if (invoiceRepository.findByInvoiceNumber(invoice.getInvoiceNumber()) != null) {
            LOGGER.debug("Invoice is already there in DB {}", StringUtils.join(invoice));
            throw new BusinessException("The Invoice is already present ");
        }
        LOGGER.debug("Invoice added Succesfully {} ", StringUtils.join(invoice));
        return invoiceRepository.save(invoice);
    }

    @Override
    public Invoice upDateInvoice(String invoiceNumber, Invoice invoice) {
        // TODO Auto-generated method stub
        if (invoiceRepository.findByInvoiceNumber(invoiceNumber) == null) {
            LOGGER.debug("Invoice is there in The DB {}", StringUtils.join(invoice));
            throw new BusinessException("Invoice is not exist in the DB.. ");
        }
        LOGGER.debug("Invoice updated successfully ..");
        return invoiceRepository.save(invoice);
    }

    @Override
    public boolean deleteInvoice(String invoiceNumber, Invoice invoice) {
        // TODO Auto-generated method stub
        if (invoiceRepository.findByInvoiceNumber(invoiceNumber) == null) {
            LOGGER.debug("Invoice is there in The DB {}", StringUtils.join(invoice));
            throw new BusinessException("Invoice is not exist in the DB.. ");
        }
        LOGGER.debug("Invoice deleted successfully ..");
        invoiceRepository.delete(invoice);
        return true;
    }

    @Override
    public List<Invoice> getAllInvoice() {
        // TODO Auto-generated method stub
        LOGGER.debug("All Invoice are ..");
        return invoiceRepository.findAll();
    }

    @Override
    public List<Invoice> listInvoiceSortByInvoiceDate() {
        // TODO Auto-generated method stub
        LOGGER.debug("All invoice sorted BY date..");
        return invoiceRepository.findAll(Sort.by("invoiceDate"));
    }

    @Override
    public List<Invoice> listInvoiceSortByInvoiceStatus() {
        // TODO Auto-generated method stub
        LOGGER.debug("All invoice sort by invoice status");
        return invoiceRepository.findAll(Sort.by("invoiceStatus"));
    }

}
