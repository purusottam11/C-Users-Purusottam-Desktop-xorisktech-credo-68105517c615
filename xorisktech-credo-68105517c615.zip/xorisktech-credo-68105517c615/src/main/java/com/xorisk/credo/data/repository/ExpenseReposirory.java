package com.xorisk.credo.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.xorisk.credo.data.Expense;

public interface ExpenseReposirory extends JpaRepository<Expense, Long>, JpaSpecificationExecutor<Expense> {

}
