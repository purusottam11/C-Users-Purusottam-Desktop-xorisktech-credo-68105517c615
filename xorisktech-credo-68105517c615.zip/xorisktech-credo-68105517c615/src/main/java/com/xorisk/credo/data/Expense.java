package com.xorisk.credo.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.apache.commons.lang3.StringUtils;

@Entity
@Table(name = "EXPENSES")
public class Expense extends AuditableIdEntity {

    public enum Type {
        TRAVEL, FOOD, OFFICE, HOTEL;
        public static Type parse(String expenseType) {
            for (Type type : values()) {
                if (StringUtils.endsWithIgnoreCase(type.name(), expenseType)) {
                    return type;
                }
            }
            return null;
        }
    }

    // public enum SubType {
    // A, B;
    // public static SubType parse(String expenseType) {
    // for (SubType subType : values()) {
    // if (StringUtils.endsWithIgnoreCase(subType.name(), expenseType)) {
    // return subType;
    // }
    // }
    // return null;
    // }
    @NotNull(message = "Date of the expense is required")
    @Column(name = "DOE")
    private Date doe;

    @NotNull(message = "Vender name is required")
    @Column(name = "VENDER_NAME")
    private String vendorName;

    @NotNull(message = "City name is required")
    @Column(name = "CITY")
    private String city;

    @Column(name = "BILLABLE")
    private boolean billable;

    @Column(name = "REMBURSABLE")
    private boolean reimbursable;

    @NotNull(message = "Customer name is required")
    @Column(name = "CUSTOMER_NAME")
    private String customerName;

    @NotNull(message = "Project name is required")
    @Column(name = "PROJECT_NAME")
    String projectName;

    @NotNull(message = "Expenses type name is required")
    @Column(name = "EXPENSE_TYPE")
    private Type type;
    //
    // @NotNull(message = "Expenses sub type Vender name is required")
    // @Column(name = "EXPENSE_SUBTYPE")
    // SubType subType;

    public Date getDoe() {
        return doe;
    }

    public void setDoe(Date doe) {
        this.doe = doe;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public boolean isBillable() {
        return billable;
    }

    public void setBillable(boolean billable) {
        this.billable = billable;
    }

    public boolean isReimbursable() {
        return reimbursable;
    }

    public void setReimbursable(boolean reimbursable) {
        this.reimbursable = reimbursable;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

}
