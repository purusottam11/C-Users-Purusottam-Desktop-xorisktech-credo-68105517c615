package com.xorisk.credo.web.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.xorisk.credo.data.User;
import com.xorisk.credo.service.api.UserService;
import com.xorisk.credo.web.BusinessException;
import com.xorisk.credo.web.bean.UserSearchFilter;

@Controller
public class UserController {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    private UserService userService;

    @GetMapping("/users")
    public String listAllUsers(Model model) {
        model.addAttribute("users", userService.getAllUsers());
        return "users";
    }

    @GetMapping("/user/")
    public String gotoAddUserPage(Model model, RedirectAttributes redirectAttributes) {
        return gotoUserDetailsPage(null, model, redirectAttributes);
    }

    @PostMapping("/user/")
    public String addUser(@ModelAttribute @Valid User user, Model model, RedirectAttributes redirectAttributes) {
        // TODO add validations
        String message;
        try {
            user = userService.addUser(user);
            message = "User added successfully";
        } catch (Exception e) {
            LOGGER.error("Error while adding user", e);
            message = "Unable to add user";
        }
        model.addAttribute("user", user);
        redirectAttributes.addFlashAttribute("status", message);
        return "redirect:/users";
    }

    @GetMapping("/user/{userId}")
    public String gotoUserDetailsPage(@PathVariable(value = "userId", required = false) Long userId, Model model, RedirectAttributes redirectAttributes) {
        if (userId == null) {
            model.addAttribute("user", new User());
        } else {
            model.addAttribute("user", userService.getUser(userId));
        }
        return "user";
    }

    @PostMapping("/user/{userId}")
    public String saveUser(@PathVariable(value = "userId", required = false) Long userId, @ModelAttribute @Valid User user, BindingResult bindingResult, Model model, RedirectAttributes redirectAttributes) {
        // TODO add validations
        String message;
        String nextPage;
        try {
            user = userService.updateUser(userId, user);
            message = "User added successfully";
            nextPage = listAllUsers(model);
        } catch (Exception e) {
            LOGGER.error("Error while adding user", e);
            message = "Unable to add user";
            nextPage = gotoUserDetailsPage(userId, model, redirectAttributes);
        }
        redirectAttributes.addFlashAttribute("status", message);
        return "redirect:/" + nextPage;
    }

    @DeleteMapping("/user/{emailId}")
    public String delete(@PathVariable String emailId, Model model, RedirectAttributes redirectAttributes) {
        // TODO add validations
        String message;
        try {
            userService.delete(emailId);
            message = "User deleted successfully";
        } catch (BusinessException e) {
            LOGGER.error("Error while deleting user", e);
            message = e.getMessage();
        } catch (Exception e) {
            LOGGER.error("Error while deleting user", e);
            message = "Unable to delete user";
        }
        redirectAttributes.addFlashAttribute("status", message);
        return "redirect:user";
    }

    @GetMapping("/users/sorted/{sortBy}")
    public String listUsersSortedByAge(@PathVariable("sortBy") String sortBy, Model model) {
        String typeName = null;
        List<User> users = null;
        if (sortBy.equalsIgnoreCase("age")) {
            typeName = "Sorted by Age";
            users = userService.listUsersSortedByAge();
        } else {
            typeName = "Sorted by Name";
            users = userService.listUsersSortedByName();
        }
        model.addAttribute("type", "list");
        model.addAttribute("typeName", typeName);
        model.addAttribute("field", sortBy);
        model.addAttribute("users", users);
        return "users";
    }

    @GetMapping("/users/search")
    public String search(UserSearchFilter userSearchFilter, Model model) {
        model.addAttribute("searchFilter", userSearchFilter);
        model.addAttribute("users", userService.search(userSearchFilter));
        return "users";
    }

    @GetMapping("/users/group/{groupBy}")
    public String group(@PathVariable("groupBy") String groupBy, Model model) {
        String typeName = null;
        Map<?, List<User>> usersGroup = null;
        if (groupBy.equalsIgnoreCase("dob_month")) {
            typeName = "Grouped by DoB Months";
            usersGroup = userService.groupUsersByMonthOfBirth();
        } else if (groupBy.equalsIgnoreCase("state")) {
            typeName = "Grouped by States";
            usersGroup = userService.groupUsersByState();
        }
        model.addAttribute("type", "map");
        model.addAttribute("typeName", typeName);
        model.addAttribute("field", groupBy);
        model.addAttribute("users", usersGroup);

        return "users";
    }

}
