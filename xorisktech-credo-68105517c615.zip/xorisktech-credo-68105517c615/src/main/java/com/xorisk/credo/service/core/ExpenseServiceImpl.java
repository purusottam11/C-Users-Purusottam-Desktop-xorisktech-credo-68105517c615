package com.xorisk.credo.service.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Component;

import com.xorisk.credo.data.Expense;
import com.xorisk.credo.data.repository.ExpenseReposirory;
import com.xorisk.credo.service.api.ExpenseService;
import com.xorisk.credo.web.bean.ExpenseSearchFilter;

@Component
public class ExpenseServiceImpl implements ExpenseService {

    private final Logger LOGGER = LoggerFactory.getLogger(getClass());

    @Autowired
    private ExpenseReposirory expenseRepository;

    @Override
    public List<Expense> getAllExpenses() {
        // TODO Auto-generated method stub
        return expenseRepository.findAll();
    }

    @Override
    public Expense getExpense(Long id) {
        // TODO Auto-generated method stub
        return expenseRepository.getOne(id);
    }

    @Override
    public Expense addExpense(Expense expense) {
        // TODO Auto-generated method stub

        return expenseRepository.save(expense);
    }

    @Override
    public Expense updateExpense(Expense expense) {
        // TODO Auto-generated method stub
        return expenseRepository.save(expense);
    }

    private Specification<Expense> getDoeRangeSpec(Date minDate, Date maxDate) {
        Specification<Expense> doeRangSpec = new Specification<Expense>() {
            public Predicate toPredicate(Root<Expense> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                if (minDate != null && maxDate != null) {
                    return criteriaBuilder.between(root.get("doe"), maxDate, minDate);
                } else if (minDate == null) {
                    return criteriaBuilder.greaterThanOrEqualTo(root.get("doe"), maxDate);
                } else {
                    return criteriaBuilder.lessThanOrEqualTo(root.get("doe"), minDate);
                }
            }
        };
        return doeRangSpec;
    }

    @Override
    public List<Expense> search(ExpenseSearchFilter expenseSearchFilter) {
        // TODO Auto-generated method stub
        Specification<Expense> searchSpec = new Specification<Expense>() {
            public Predicate toPredicate(Root<Expense> root, CriteriaQuery<?> query, CriteriaBuilder criteriaBuilder) {
                List<Predicate> predicates = new ArrayList<>();
                if (expenseSearchFilter.getMinDoe() != null || expenseSearchFilter.getMaxDoe() != null) {
                    predicates.add(getDoeRangeSpec(expenseSearchFilter.getMinDoe(), expenseSearchFilter.getMaxDoe()).toPredicate(root, query, criteriaBuilder));
                }
                if (StringUtils.isNotBlank(expenseSearchFilter.getProjectName())) {
                    predicates.add(criteriaBuilder.equal(root.get("projectName"), expenseSearchFilter.getProjectName()));
                }
                if (expenseSearchFilter.getType() != null) {
                    predicates.add(criteriaBuilder.equal(root.get("type"), expenseSearchFilter.getType()));
                }
                return criteriaBuilder.and(predicates.toArray(new Predicate[predicates.size()]));
            }
        };

        List<Expense> searchResult = expenseRepository.findAll(searchSpec);

        LOGGER.debug("Search {} ", expenseSearchFilter);
        LOGGER.debug("Result {} ", searchResult);
        return searchResult;
    }
}
