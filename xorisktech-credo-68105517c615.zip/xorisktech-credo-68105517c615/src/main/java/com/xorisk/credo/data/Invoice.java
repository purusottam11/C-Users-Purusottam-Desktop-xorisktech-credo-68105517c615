package com.xorisk.credo.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import org.apache.commons.lang3.StringUtils;

@Entity
@Table(name = "INVOICE")
public class Invoice extends AuditableIdEntity {

    public enum InvoiceStatus {
        PAY, PAID;
        public static InvoiceStatus parse(String invoiceStatusString) {
            for (InvoiceStatus invoiceStatus : values()) {
                if (StringUtils.endsWithIgnoreCase(invoiceStatus.name(), invoiceStatusString)) {
                    return invoiceStatus;
                }
            }
            return null;
        }
    }

    @Column(name = "INVOICE_DATE")
    private Date invoiceDate;

    @Column(name = "INVOICE_NUMBER")
    private String invoiceNumber;

    // Dropdown link to vendor table
    @Column(name = "VENDOR_Id")
    private Long vendorId;

    @Column(name = "INVOICE_AMOUNT")
    private float invoiceAmount;

    @Column(name = "IGST")
    private boolean igst;

    @Column(name = "SGST_OR_GST")
    private boolean sgstOrGst;

    @Column(name = "IGST_AMOUNT")
    private float igstAmount;

    @Column(name = "GST_AMOUNT")
    private float gstAmount;

    @Column(name = "SGST_AMOUNT")
    private float sgstAmount;

    @Column(name = "TAX_NUMBER")
    private String taxNumber;

    @Column(name = "TOTAL_AMOUNT")
    private float totalAmount;

    @Column(name = "INVOICE_DESCRIPTION")
    private String invoiceDescription;

    @Column(name = "Invoice Starus")
    private InvoiceStatus invoiceStatus;

    public Date getInvoicedate() {
        return invoiceDate;
    }

    public void setInvoicedate(Date invoicedate) {
        this.invoiceDate = invoicedate;
    }

    public String getInvoiceNumber() {
        return invoiceNumber;
    }

    public void setInvoiceNumber(String invoiceNumber) {
        this.invoiceNumber = invoiceNumber;
    }

    public Long getVendorId() {
        return vendorId;
    }

    public void setVendorId(Long vendorId) {
        this.vendorId = vendorId;
    }

    public float getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(float invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public boolean isIgst() {
        return igst;
    }

    public void setIgst(boolean igst) {
        this.igst = igst;
    }

    public boolean isSgstOrGst() {
        return sgstOrGst;
    }

    public void setSgstOrGst(boolean sgstOrGst) {
        this.sgstOrGst = sgstOrGst;
    }

    public float getIgstAmount() {
        return igstAmount;
    }

    public void setIgstAmount(float igstAmount) {
        this.igstAmount = igstAmount;
    }

    public float getGstAmount() {
        return gstAmount;
    }

    public void setGstAmount(float gstAmount) {
        this.gstAmount = gstAmount;
    }

    public float getSgstAmount() {
        return sgstAmount;
    }

    public void setSgstAmount(float sgstAmount) {
        this.sgstAmount = sgstAmount;
    }

    public String getTaxNumber() {
        return taxNumber;
    }

    public void setTaxNumber(String taxNumber) {
        this.taxNumber = taxNumber;
    }

    public float getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(float totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getInvoiceDescription() {
        return invoiceDescription;
    }

    public void setInvoiceDescription(String invoiceDescription) {
        this.invoiceDescription = invoiceDescription;
    }

    public InvoiceStatus getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(InvoiceStatus invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    @Override
    public String toString() {
        return "Invoice [invoicedate=" + invoiceDate + ", invoiceNumber=" + invoiceNumber + ", vendorId=" + vendorId + ", invoiceAmount=" + invoiceAmount + ", igst=" + igst + ", sgstOrGst=" + sgstOrGst + ", igstAmount=" + igstAmount
                + ", gstAmount=" + gstAmount + ", sgstAmount=" + sgstAmount + ", taxNumber=" + taxNumber + ", totalAmount=" + totalAmount + ", invoiceDescription=" + invoiceDescription + ", invoiceStatus=" + invoiceStatus + "]";
    }

}
