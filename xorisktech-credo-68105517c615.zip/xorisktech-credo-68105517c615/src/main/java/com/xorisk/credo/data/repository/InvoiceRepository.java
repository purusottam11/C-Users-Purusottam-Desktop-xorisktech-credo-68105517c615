package com.xorisk.credo.data.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.xorisk.credo.data.Invoice;

public interface InvoiceRepository extends JpaRepository<Invoice, Long>, JpaSpecificationExecutor<Invoice> {

    @Query("select i from Invoice i where i.invoiceNumber=:invoiceNumber")
    Invoice findByInvoiceNumber(@Param("invoiceNumber") String invoiceNumber);

}
