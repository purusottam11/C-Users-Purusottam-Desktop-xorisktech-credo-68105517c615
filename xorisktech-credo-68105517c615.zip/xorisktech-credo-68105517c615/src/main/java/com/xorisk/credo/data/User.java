package com.xorisk.credo.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "USERS")
public class User extends AuditableIdEntity {

    public enum Gender {
        MALE, FEMALE;

        public static Gender parse(String genderString) {
            for (Gender gender : values()) {
                if (StringUtils.endsWithIgnoreCase(gender.name(), genderString)) {
                    return gender;
                }
            }
            return null;
        }
    }

    @NotNull(message = "Email Address is required")
    @NotBlank(message = "Email Address is required")
    @Email(message = "Email Address is not a valid format")
    @Column(name = "EMAIL_ID")
    private String emailId;

    @NotNull(message = "First name is required")
    @Column(name = "FIRST_NAME")
    private String firstName;

    @NotNull(message = "Last name is required")
    @Column(name = "LAST_NAME")
    private String lastName;

    @NotNull(message = "Gender is compulsory")
    @Column(name = "GENDER")
    private Gender gender;

    @Past(message = "Invalid date of birth")
    @NotNull
    @Column(name = "DOB")
    @DateTimeFormat(pattern = "dd/MM/yyyy")
    private Date dob;

    @NotNull
    @Column(name = "ADDRESS")
    private String address;

    @NotNull(message = "Pincode is compulsory")
    @Column(name = "PINCODE")
    private String pincode;

    @NotNull(message = "City is compulsory")
    @Column(name = "CITY")
    private String city;

    @NotNull(message = "State is compusory")
    @Column(name = "STATE")
    private String state;

    @NotNull(message = "Country is compusory")
    @Column(name = "COUNTRY")
    private String country;

    @NotNull
    @Size(min = 0, max = 10)
    @Column(name = "PHONE")
    private String phone;

    @Column(name = "WEBSITE")
    private String website;

    @Column(name = "NOTES")
    private String notes;

    public User() {
    }

    // first_name,last_name,email,gender,dob,address,city,state,pincode,phone,website,note,country
    public User(@NotNull(message = "First name is required") String firstName, @NotNull(message = "Last name is required") String lastName,
            @NotNull(message = "Email Address is required") @NotBlank(message = "Email Address is required") @Email(message = "Email Address is not a valid format") String emailId, @NotNull(message = "Gender is compulsory") Gender gender,
            @Past(message = "Invalid date of birth") @NotNull Date dob, @NotNull String address, @NotNull String city, @NotNull String state, @NotNull String pincode, @NotNull @Size(min = 0, max = 10) String phone, String website,
            String notes, String country) {
        this.emailId = emailId;
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.dob = dob;
        this.address = address;
        this.city = city;
        this.state = state;
        this.pincode = pincode;
        this.website = website;
        this.phone = phone;
        this.notes = notes;
        this.country = country;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Gender getGender() {
        return gender;
    }

    public void setGender(Gender gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getWebsite() {
        return website;
    }

    public void setWebsite(String website) {
        this.website = website;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    @Override
    public String toString() {
        return "User [emailId=" + emailId + ", firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", dob=" + dob + ", address=" + address + ", pincode=" + pincode + ", city=" + city + ", state=" + state
                + ", country=" + country + ", phone=" + phone + ", website=" + website + ", notes=" + notes + "]";
    }

}
