package com.xorisk.credo.data;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.MappedSuperclass;
import javax.persistence.PreUpdate;

import org.hibernate.annotations.Type;

@MappedSuperclass
public abstract class AuditableIdEntity extends IdEntity {

    @Column(name = "MODIFIED_BY")
    private Long modifiedBy;

    @Column(name = "MODIFIED_DATE", nullable = false)
    private Date modifiedDate = new Date();

    @Column(name = "DELETED", nullable = false)
    @Type(type = "yes_no")
    private boolean deleted = false;

    @PreUpdate
    public void onUpdate() {
        this.setModifiedDate(new Date());
    }

    public Long getModifiedBy() {
        return modifiedBy;
    }

    public void setModifiedBy(Long modifiedBy) {
        this.modifiedBy = modifiedBy;
    }

    public Date getModifiedDate() {
        return modifiedDate;
    }

    public void setModifiedDate(Date modifiedDate) {
        this.modifiedDate = modifiedDate;
    }

    public boolean isDeleted() {
        return deleted;
    }

    public void setDeleted(boolean deleted) {
        this.deleted = deleted;
    }

}